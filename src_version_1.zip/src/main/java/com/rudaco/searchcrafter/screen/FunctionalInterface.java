package com.rudaco.searchcrafter.screen;

public interface FunctionalInterface {
    void ejecutar();
}
