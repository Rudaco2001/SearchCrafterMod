package com.rudaco.searchcrafter.staticInfo;

import com.rudaco.searchcrafter.block.entity.SearchCrafterTable;
import com.rudaco.searchcrafter.screen.CraftableInfo;
import com.rudaco.searchcrafter.screen.PageController;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;

public class StaticInfo {
    public static ArrayList<CraftableInfo> chestItems = new ArrayList<>();

    public static PageController controller = null;



}
