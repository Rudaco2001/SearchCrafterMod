package com.rudaco.searchcrafter.staticInfo;

public class Pair<T, P> {
    public T first;
    public P second;
    public Pair(T first, P second){
        this.first = first;
        this.second = second;
    }
}
